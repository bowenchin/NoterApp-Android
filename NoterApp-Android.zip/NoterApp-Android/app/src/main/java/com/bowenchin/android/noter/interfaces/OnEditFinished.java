package com.bowenchin.android.noter.interfaces;

/**
 * Created by bowenchin on 28/12/15.
 */
public interface OnEditFinished {
    //Called when the user finishes editing a task.

    public void finishedEditingTask();
}
