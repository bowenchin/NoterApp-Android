package com.bowenchin.android.noter.interfaces;

/**
 * Created by bowenchin on 27/12/15.
 */
public interface OnEditTask {
    /**
     * Called when the user asks to edit or insert a task.
     */
    public void editTask(long id);
}
